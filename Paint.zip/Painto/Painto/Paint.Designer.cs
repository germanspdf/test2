﻿namespace Paint_MB
{
    partial class Paint
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel = new System.Windows.Forms.Panel();
            this.menu_pnl = new System.Windows.Forms.Panel();
            this.adelante_btn = new System.Windows.Forms.Button();
            this.atras_btn = new System.Windows.Forms.Button();
            this.abrir_btn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.pegar_btn = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.relleno_btn = new System.Windows.Forms.Button();
            this.texto_btn = new System.Windows.Forms.Button();
            this.poligono_btn = new System.Windows.Forms.Button();
            this.trianguo_btn = new System.Windows.Forms.Button();
            this.circulo_btn = new System.Windows.Forms.Button();
            this.rectangulo_btn = new System.Windows.Forms.Button();
            this.cuadrado_btn = new System.Windows.Forms.Button();
            this.linea_btn = new System.Windows.Forms.Button();
            this.borrador_btn = new System.Windows.Forms.Button();
            this.manoAlzada_btn = new System.Windows.Forms.Button();
            this.guardar_btn = new System.Windows.Forms.Button();
            this.letraTamaño_txb = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.limpiar_btn = new System.Windows.Forms.Button();
            this.salir_btn = new System.Windows.Forms.Button();
            this.texto_txb = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.caras_txb = new System.Windows.Forms.TextBox();
            this.tamaño_spn = new System.Windows.Forms.NumericUpDown();
            this.menu_pnl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tamaño_spn)).BeginInit();
            this.SuspendLayout();
            // 
            // panel
            // 
            this.panel.BackColor = System.Drawing.Color.White;
            this.panel.Cursor = System.Windows.Forms.Cursors.Cross;
            this.panel.Location = new System.Drawing.Point(0, 0);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(1350, 729);
            this.panel.TabIndex = 0;
            this.panel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel_MouseClick);
            this.panel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_MouseDown);
            this.panel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel_MouseMove);
            this.panel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel_MouseUp);
            // 
            // menu_pnl
            // 
            this.menu_pnl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(116)))), ((int)(((byte)(66)))));
            this.menu_pnl.Controls.Add(this.tamaño_spn);
            this.menu_pnl.Controls.Add(this.adelante_btn);
            this.menu_pnl.Controls.Add(this.atras_btn);
            this.menu_pnl.Controls.Add(this.abrir_btn);
            this.menu_pnl.Controls.Add(this.button1);
            this.menu_pnl.Controls.Add(this.pegar_btn);
            this.menu_pnl.Controls.Add(this.button2);
            this.menu_pnl.Controls.Add(this.relleno_btn);
            this.menu_pnl.Controls.Add(this.texto_btn);
            this.menu_pnl.Controls.Add(this.poligono_btn);
            this.menu_pnl.Controls.Add(this.trianguo_btn);
            this.menu_pnl.Controls.Add(this.circulo_btn);
            this.menu_pnl.Controls.Add(this.rectangulo_btn);
            this.menu_pnl.Controls.Add(this.cuadrado_btn);
            this.menu_pnl.Controls.Add(this.linea_btn);
            this.menu_pnl.Controls.Add(this.borrador_btn);
            this.menu_pnl.Controls.Add(this.manoAlzada_btn);
            this.menu_pnl.Controls.Add(this.guardar_btn);
            this.menu_pnl.Controls.Add(this.letraTamaño_txb);
            this.menu_pnl.Controls.Add(this.label3);
            this.menu_pnl.Controls.Add(this.label2);
            this.menu_pnl.Controls.Add(this.limpiar_btn);
            this.menu_pnl.Controls.Add(this.salir_btn);
            this.menu_pnl.Controls.Add(this.texto_txb);
            this.menu_pnl.Controls.Add(this.label1);
            this.menu_pnl.Controls.Add(this.caras_txb);
            this.menu_pnl.Location = new System.Drawing.Point(0, 0);
            this.menu_pnl.Name = "menu_pnl";
            this.menu_pnl.Size = new System.Drawing.Size(268, 729);
            this.menu_pnl.TabIndex = 1;
            // 
            // adelante_btn
            // 
            this.adelante_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adelante_btn.Location = new System.Drawing.Point(213, 24);
            this.adelante_btn.Name = "adelante_btn";
            this.adelante_btn.Size = new System.Drawing.Size(39, 23);
            this.adelante_btn.TabIndex = 46;
            this.adelante_btn.Text = "->";
            this.adelante_btn.UseVisualStyleBackColor = true;
            this.adelante_btn.Click += new System.EventHandler(this.adelante_btn_Click);
            // 
            // atras_btn
            // 
            this.atras_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.atras_btn.Location = new System.Drawing.Point(168, 24);
            this.atras_btn.Name = "atras_btn";
            this.atras_btn.Size = new System.Drawing.Size(39, 23);
            this.atras_btn.TabIndex = 45;
            this.atras_btn.Text = "<-";
            this.atras_btn.UseVisualStyleBackColor = true;
            this.atras_btn.Click += new System.EventHandler(this.atras_btn_Click);
            // 
            // abrir_btn
            // 
            this.abrir_btn.BackColor = System.Drawing.Color.Transparent;
            this.abrir_btn.Location = new System.Drawing.Point(86, 12);
            this.abrir_btn.Name = "abrir_btn";
            this.abrir_btn.Size = new System.Drawing.Size(75, 35);
            this.abrir_btn.TabIndex = 44;
            this.abrir_btn.Text = "Abrir";
            this.abrir_btn.UseVisualStyleBackColor = false;
            this.abrir_btn.Click += new System.EventHandler(this.abrir_btn_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(12, 499);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(84, 41);
            this.button1.TabIndex = 43;
            this.button1.Text = "Color Picker";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.eleccionColor);
            // 
            // pegar_btn
            // 
            this.pegar_btn.Location = new System.Drawing.Point(177, 129);
            this.pegar_btn.Name = "pegar_btn";
            this.pegar_btn.Size = new System.Drawing.Size(75, 23);
            this.pegar_btn.TabIndex = 40;
            this.pegar_btn.Text = "Pegar";
            this.pegar_btn.UseVisualStyleBackColor = true;
            this.pegar_btn.Click += new System.EventHandler(this.accion);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(89, 129);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 39;
            this.button2.Text = "Recortar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.accion);
            // 
            // relleno_btn
            // 
            this.relleno_btn.Location = new System.Drawing.Point(86, 204);
            this.relleno_btn.Name = "relleno_btn";
            this.relleno_btn.Size = new System.Drawing.Size(75, 23);
            this.relleno_btn.TabIndex = 38;
            this.relleno_btn.Text = "Relleno";
            this.relleno_btn.UseVisualStyleBackColor = true;
            this.relleno_btn.Click += new System.EventHandler(this.accion);
            // 
            // texto_btn
            // 
            this.texto_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.texto_btn.Location = new System.Drawing.Point(0, 323);
            this.texto_btn.Name = "texto_btn";
            this.texto_btn.Size = new System.Drawing.Size(75, 23);
            this.texto_btn.TabIndex = 37;
            this.texto_btn.Text = "Texto";
            this.texto_btn.UseVisualStyleBackColor = true;
            this.texto_btn.Click += new System.EventHandler(this.accion);
            // 
            // poligono_btn
            // 
            this.poligono_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.poligono_btn.Location = new System.Drawing.Point(0, 292);
            this.poligono_btn.Name = "poligono_btn";
            this.poligono_btn.Size = new System.Drawing.Size(75, 25);
            this.poligono_btn.TabIndex = 36;
            this.poligono_btn.Text = "Poligono";
            this.poligono_btn.UseVisualStyleBackColor = true;
            this.poligono_btn.Click += new System.EventHandler(this.accion);
            // 
            // trianguo_btn
            // 
            this.trianguo_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trianguo_btn.Location = new System.Drawing.Point(0, 262);
            this.trianguo_btn.Name = "trianguo_btn";
            this.trianguo_btn.Size = new System.Drawing.Size(75, 23);
            this.trianguo_btn.TabIndex = 35;
            this.trianguo_btn.Text = "Triangulo";
            this.trianguo_btn.UseVisualStyleBackColor = true;
            this.trianguo_btn.Click += new System.EventHandler(this.accion);
            // 
            // circulo_btn
            // 
            this.circulo_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.circulo_btn.Location = new System.Drawing.Point(0, 233);
            this.circulo_btn.Name = "circulo_btn";
            this.circulo_btn.Size = new System.Drawing.Size(75, 23);
            this.circulo_btn.TabIndex = 34;
            this.circulo_btn.Text = "Circulo";
            this.circulo_btn.UseVisualStyleBackColor = true;
            this.circulo_btn.Click += new System.EventHandler(this.accion);
            // 
            // rectangulo_btn
            // 
            this.rectangulo_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rectangulo_btn.Location = new System.Drawing.Point(0, 204);
            this.rectangulo_btn.Name = "rectangulo_btn";
            this.rectangulo_btn.Size = new System.Drawing.Size(75, 23);
            this.rectangulo_btn.TabIndex = 33;
            this.rectangulo_btn.Text = "Rectangulo";
            this.rectangulo_btn.UseVisualStyleBackColor = true;
            this.rectangulo_btn.Click += new System.EventHandler(this.accion);
            // 
            // cuadrado_btn
            // 
            this.cuadrado_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cuadrado_btn.Location = new System.Drawing.Point(0, 175);
            this.cuadrado_btn.Name = "cuadrado_btn";
            this.cuadrado_btn.Size = new System.Drawing.Size(75, 23);
            this.cuadrado_btn.TabIndex = 32;
            this.cuadrado_btn.Text = "Cuadrado";
            this.cuadrado_btn.UseVisualStyleBackColor = true;
            this.cuadrado_btn.Click += new System.EventHandler(this.accion);
            // 
            // linea_btn
            // 
            this.linea_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linea_btn.Location = new System.Drawing.Point(0, 146);
            this.linea_btn.Name = "linea_btn";
            this.linea_btn.Size = new System.Drawing.Size(75, 23);
            this.linea_btn.TabIndex = 31;
            this.linea_btn.Text = "Linea";
            this.linea_btn.UseVisualStyleBackColor = true;
            this.linea_btn.Click += new System.EventHandler(this.accion);
            // 
            // borrador_btn
            // 
            this.borrador_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.borrador_btn.Location = new System.Drawing.Point(0, 117);
            this.borrador_btn.Name = "borrador_btn";
            this.borrador_btn.Size = new System.Drawing.Size(75, 23);
            this.borrador_btn.TabIndex = 30;
            this.borrador_btn.Text = "Borrador";
            this.borrador_btn.UseVisualStyleBackColor = true;
            this.borrador_btn.Click += new System.EventHandler(this.accion);
            // 
            // manoAlzada_btn
            // 
            this.manoAlzada_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.manoAlzada_btn.Location = new System.Drawing.Point(0, 79);
            this.manoAlzada_btn.Name = "manoAlzada_btn";
            this.manoAlzada_btn.Size = new System.Drawing.Size(75, 23);
            this.manoAlzada_btn.TabIndex = 29;
            this.manoAlzada_btn.Text = "Lapiz";
            this.manoAlzada_btn.UseVisualStyleBackColor = true;
            this.manoAlzada_btn.Click += new System.EventHandler(this.accion);
            // 
            // guardar_btn
            // 
            this.guardar_btn.BackColor = System.Drawing.Color.DodgerBlue;
            this.guardar_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guardar_btn.Location = new System.Drawing.Point(3, 12);
            this.guardar_btn.Name = "guardar_btn";
            this.guardar_btn.Size = new System.Drawing.Size(72, 35);
            this.guardar_btn.TabIndex = 28;
            this.guardar_btn.Text = "Guardar";
            this.guardar_btn.UseVisualStyleBackColor = false;
            this.guardar_btn.Click += new System.EventHandler(this.guardar_btn_Click);
            // 
            // letraTamaño_txb
            // 
            this.letraTamaño_txb.Location = new System.Drawing.Point(69, 442);
            this.letraTamaño_txb.Name = "letraTamaño_txb";
            this.letraTamaño_txb.Size = new System.Drawing.Size(93, 20);
            this.letraTamaño_txb.TabIndex = 22;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 442);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 13);
            this.label3.TabIndex = 24;
            this.label3.Text = "Tamaño";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 391);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 13);
            this.label2.TabIndex = 23;
            this.label2.Text = "Texto";
            // 
            // limpiar_btn
            // 
            this.limpiar_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.limpiar_btn.Location = new System.Drawing.Point(168, 499);
            this.limpiar_btn.Name = "limpiar_btn";
            this.limpiar_btn.Size = new System.Drawing.Size(84, 41);
            this.limpiar_btn.TabIndex = 2;
            this.limpiar_btn.Text = "Limpiar";
            this.limpiar_btn.UseVisualStyleBackColor = true;
            this.limpiar_btn.Click += new System.EventHandler(this.limpiar_btn_Click);
            // 
            // salir_btn
            // 
            this.salir_btn.Location = new System.Drawing.Point(168, 581);
            this.salir_btn.Name = "salir_btn";
            this.salir_btn.Size = new System.Drawing.Size(84, 41);
            this.salir_btn.TabIndex = 22;
            this.salir_btn.Text = "Salir";
            this.salir_btn.UseVisualStyleBackColor = true;
            this.salir_btn.Click += new System.EventHandler(this.salir_btn_Click);
            // 
            // texto_txb
            // 
            this.texto_txb.Location = new System.Drawing.Point(52, 391);
            this.texto_txb.Name = "texto_txb";
            this.texto_txb.Size = new System.Drawing.Size(197, 20);
            this.texto_txb.TabIndex = 22;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(86, 281);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "No. Caras";
            // 
            // caras_txb
            // 
            this.caras_txb.Location = new System.Drawing.Point(86, 297);
            this.caras_txb.Name = "caras_txb";
            this.caras_txb.Size = new System.Drawing.Size(45, 20);
            this.caras_txb.TabIndex = 2;
            // 
            // tamaño_spn
            // 
            this.tamaño_spn.Location = new System.Drawing.Point(101, 79);
            this.tamaño_spn.Name = "tamaño_spn";
            this.tamaño_spn.Size = new System.Drawing.Size(39, 20);
            this.tamaño_spn.TabIndex = 47;
            this.tamaño_spn.Click += new System.EventHandler(this.tamaño);
            // 
            // Paint
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1350, 729);
            this.Controls.Add(this.menu_pnl);
            this.Controls.Add(this.panel);
            this.Name = "Paint";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.LocationChanged += new System.EventHandler(this.CambiarForm);
            this.SizeChanged += new System.EventHandler(this.CambiarForm);
            this.menu_pnl.ResumeLayout(false);
            this.menu_pnl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tamaño_spn)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.Panel menu_pnl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox caras_txb;
        private System.Windows.Forms.Button limpiar_btn;
        private System.Windows.Forms.TextBox texto_txb;
        private System.Windows.Forms.TextBox letraTamaño_txb;
        private System.Windows.Forms.Button salir_btn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button guardar_btn;
        private System.Windows.Forms.Button texto_btn;
        private System.Windows.Forms.Button poligono_btn;
        private System.Windows.Forms.Button trianguo_btn;
        private System.Windows.Forms.Button circulo_btn;
        private System.Windows.Forms.Button rectangulo_btn;
        private System.Windows.Forms.Button cuadrado_btn;
        private System.Windows.Forms.Button linea_btn;
        private System.Windows.Forms.Button borrador_btn;
        private System.Windows.Forms.Button manoAlzada_btn;
        private System.Windows.Forms.Button pegar_btn;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button relleno_btn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button abrir_btn;
        private System.Windows.Forms.Button adelante_btn;
        private System.Windows.Forms.Button atras_btn;
        private System.Windows.Forms.NumericUpDown tamaño_spn;
    }
}

