﻿namespace Paint_MB
{
    partial class Paint
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Paint));
            this.panel = new System.Windows.Forms.Panel();
            this.menu_pnl = new System.Windows.Forms.Panel();
            this.paste_pbx = new System.Windows.Forms.PictureBox();
            this.recortar_pbx = new System.Windows.Forms.PictureBox();
            this.adelante_pbx = new System.Windows.Forms.PictureBox();
            this.letraTamaño_txb = new System.Windows.Forms.TextBox();
            this.atras_pbx = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.relleno_pbx = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.limpiar_btn = new System.Windows.Forms.Button();
            this.salir_btn = new System.Windows.Forms.Button();
            this.texto_txb = new System.Windows.Forms.TextBox();
            this.abrir_pbx = new System.Windows.Forms.PictureBox();
            this.texto_pbx = new System.Windows.Forms.PictureBox();
            this.guardar_pbx = new System.Windows.Forms.PictureBox();
            this.linea_pbx = new System.Windows.Forms.PictureBox();
            this.triangulo_pbx = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.circulo_pbx = new System.Windows.Forms.PictureBox();
            this.rectangulo_pbx = new System.Windows.Forms.PictureBox();
            this.caras_txb = new System.Windows.Forms.TextBox();
            this.cuadrado_pbx = new System.Windows.Forms.PictureBox();
            this.borrador_pbx = new System.Windows.Forms.PictureBox();
            this.poligono_pbx = new System.Windows.Forms.PictureBox();
            this.contador_lbl = new System.Windows.Forms.Label();
            this.mas_pbx = new System.Windows.Forms.PictureBox();
            this.menos_pbx = new System.Windows.Forms.PictureBox();
            this.colorActual_pbx = new System.Windows.Forms.PictureBox();
            this.manoAlzada_pbx = new System.Windows.Forms.PictureBox();
            this.paleta_pbx = new System.Windows.Forms.PictureBox();
            this.cafe_pbx = new System.Windows.Forms.PictureBox();
            this.rosa_pbx = new System.Windows.Forms.PictureBox();
            this.negro_pbx = new System.Windows.Forms.PictureBox();
            this.gris_pbx = new System.Windows.Forms.PictureBox();
            this.blanco_pbx = new System.Windows.Forms.PictureBox();
            this.azul_pbx = new System.Windows.Forms.PictureBox();
            this.rojo_pbx = new System.Windows.Forms.PictureBox();
            this.verde_pbx = new System.Windows.Forms.PictureBox();
            this.amarillo_pbx = new System.Windows.Forms.PictureBox();
            this.menu_pnl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.paste_pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.recortar_pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.adelante_pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.atras_pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.relleno_pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.abrir_pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.texto_pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guardar_pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.linea_pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.triangulo_pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.circulo_pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rectangulo_pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cuadrado_pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.borrador_pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.poligono_pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mas_pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.menos_pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.colorActual_pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.manoAlzada_pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.paleta_pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cafe_pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rosa_pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.negro_pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gris_pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco_pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.azul_pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rojo_pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.verde_pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.amarillo_pbx)).BeginInit();
            this.SuspendLayout();
            // 
            // panel
            // 
            this.panel.BackColor = System.Drawing.Color.White;
            this.panel.Cursor = System.Windows.Forms.Cursors.Cross;
            this.panel.Location = new System.Drawing.Point(0, 0);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(1350, 729);
            this.panel.TabIndex = 0;
            this.panel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel_MouseClick);
            this.panel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_MouseDown);
            this.panel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel_MouseMove);
            this.panel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel_MouseUp);
            // 
            // menu_pnl
            // 
            this.menu_pnl.BackColor = System.Drawing.Color.LightSteelBlue;
            this.menu_pnl.Controls.Add(this.paste_pbx);
            this.menu_pnl.Controls.Add(this.recortar_pbx);
            this.menu_pnl.Controls.Add(this.adelante_pbx);
            this.menu_pnl.Controls.Add(this.letraTamaño_txb);
            this.menu_pnl.Controls.Add(this.atras_pbx);
            this.menu_pnl.Controls.Add(this.label3);
            this.menu_pnl.Controls.Add(this.relleno_pbx);
            this.menu_pnl.Controls.Add(this.label2);
            this.menu_pnl.Controls.Add(this.limpiar_btn);
            this.menu_pnl.Controls.Add(this.salir_btn);
            this.menu_pnl.Controls.Add(this.texto_txb);
            this.menu_pnl.Controls.Add(this.abrir_pbx);
            this.menu_pnl.Controls.Add(this.texto_pbx);
            this.menu_pnl.Controls.Add(this.guardar_pbx);
            this.menu_pnl.Controls.Add(this.linea_pbx);
            this.menu_pnl.Controls.Add(this.triangulo_pbx);
            this.menu_pnl.Controls.Add(this.label1);
            this.menu_pnl.Controls.Add(this.circulo_pbx);
            this.menu_pnl.Controls.Add(this.rectangulo_pbx);
            this.menu_pnl.Controls.Add(this.caras_txb);
            this.menu_pnl.Controls.Add(this.cuadrado_pbx);
            this.menu_pnl.Controls.Add(this.borrador_pbx);
            this.menu_pnl.Controls.Add(this.poligono_pbx);
            this.menu_pnl.Controls.Add(this.contador_lbl);
            this.menu_pnl.Controls.Add(this.mas_pbx);
            this.menu_pnl.Controls.Add(this.menos_pbx);
            this.menu_pnl.Controls.Add(this.colorActual_pbx);
            this.menu_pnl.Controls.Add(this.manoAlzada_pbx);
            this.menu_pnl.Controls.Add(this.paleta_pbx);
            this.menu_pnl.Controls.Add(this.cafe_pbx);
            this.menu_pnl.Controls.Add(this.rosa_pbx);
            this.menu_pnl.Controls.Add(this.negro_pbx);
            this.menu_pnl.Controls.Add(this.gris_pbx);
            this.menu_pnl.Controls.Add(this.blanco_pbx);
            this.menu_pnl.Controls.Add(this.azul_pbx);
            this.menu_pnl.Controls.Add(this.rojo_pbx);
            this.menu_pnl.Controls.Add(this.verde_pbx);
            this.menu_pnl.Controls.Add(this.amarillo_pbx);
            this.menu_pnl.Location = new System.Drawing.Point(0, 0);
            this.menu_pnl.Name = "menu_pnl";
            this.menu_pnl.Size = new System.Drawing.Size(268, 729);
            this.menu_pnl.TabIndex = 1;
            // 
            // paste_pbx
            // 
            this.paste_pbx.BackColor = System.Drawing.Color.RoyalBlue;
            this.paste_pbx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.paste_pbx.Image = global::Paint_MB.Properties.Resources.paste;
            this.paste_pbx.Location = new System.Drawing.Point(168, 12);
            this.paste_pbx.Name = "paste_pbx";
            this.paste_pbx.Size = new System.Drawing.Size(46, 46);
            this.paste_pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.paste_pbx.TabIndex = 27;
            this.paste_pbx.TabStop = false;
            this.paste_pbx.Click += new System.EventHandler(this.accion);
            // 
            // recortar_pbx
            // 
            this.recortar_pbx.BackColor = System.Drawing.Color.RoyalBlue;
            this.recortar_pbx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.recortar_pbx.Image = global::Paint_MB.Properties.Resources.tijeras_png_1384236;
            this.recortar_pbx.Location = new System.Drawing.Point(116, 12);
            this.recortar_pbx.Name = "recortar_pbx";
            this.recortar_pbx.Size = new System.Drawing.Size(46, 46);
            this.recortar_pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.recortar_pbx.TabIndex = 26;
            this.recortar_pbx.TabStop = false;
            this.recortar_pbx.Click += new System.EventHandler(this.accion);
            // 
            // adelante_pbx
            // 
            this.adelante_pbx.BackColor = System.Drawing.Color.RoyalBlue;
            this.adelante_pbx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.adelante_pbx.Image = global::Paint_MB.Properties.Resources._585e469fcb11b227491c3374;
            this.adelante_pbx.Location = new System.Drawing.Point(233, 12);
            this.adelante_pbx.Name = "adelante_pbx";
            this.adelante_pbx.Size = new System.Drawing.Size(32, 23);
            this.adelante_pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.adelante_pbx.TabIndex = 25;
            this.adelante_pbx.TabStop = false;
            this.adelante_pbx.Click += new System.EventHandler(this.adelante_pbx_Click);
            // 
            // letraTamaño_txb
            // 
            this.letraTamaño_txb.Location = new System.Drawing.Point(68, 607);
            this.letraTamaño_txb.Name = "letraTamaño_txb";
            this.letraTamaño_txb.Size = new System.Drawing.Size(93, 20);
            this.letraTamaño_txb.TabIndex = 22;
            // 
            // atras_pbx
            // 
            this.atras_pbx.BackColor = System.Drawing.Color.RoyalBlue;
            this.atras_pbx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.atras_pbx.Image = global::Paint_MB.Properties.Resources._585e4695cb11b227491c3373;
            this.atras_pbx.Location = new System.Drawing.Point(233, 41);
            this.atras_pbx.Name = "atras_pbx";
            this.atras_pbx.Size = new System.Drawing.Size(32, 23);
            this.atras_pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.atras_pbx.TabIndex = 25;
            this.atras_pbx.TabStop = false;
            this.atras_pbx.Click += new System.EventHandler(this.atras_pbx_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 610);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 13);
            this.label3.TabIndex = 24;
            this.label3.Text = "Tamaño";
            // 
            // relleno_pbx
            // 
            this.relleno_pbx.BackColor = System.Drawing.Color.RoyalBlue;
            this.relleno_pbx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.relleno_pbx.Image = global::Paint_MB.Properties.Resources.rellenar;
            this.relleno_pbx.Location = new System.Drawing.Point(12, 480);
            this.relleno_pbx.Name = "relleno_pbx";
            this.relleno_pbx.Size = new System.Drawing.Size(46, 46);
            this.relleno_pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.relleno_pbx.TabIndex = 22;
            this.relleno_pbx.TabStop = false;
            this.relleno_pbx.Click += new System.EventHandler(this.accion);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 584);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 13);
            this.label2.TabIndex = 23;
            this.label2.Text = "Texto";
            // 
            // limpiar_btn
            // 
            this.limpiar_btn.Location = new System.Drawing.Point(181, 610);
            this.limpiar_btn.Name = "limpiar_btn";
            this.limpiar_btn.Size = new System.Drawing.Size(84, 41);
            this.limpiar_btn.TabIndex = 2;
            this.limpiar_btn.Text = "Limpiar todo";
            this.limpiar_btn.UseVisualStyleBackColor = true;
            this.limpiar_btn.Click += new System.EventHandler(this.limpiar_btn_Click);
            // 
            // salir_btn
            // 
            this.salir_btn.Location = new System.Drawing.Point(181, 656);
            this.salir_btn.Name = "salir_btn";
            this.salir_btn.Size = new System.Drawing.Size(84, 41);
            this.salir_btn.TabIndex = 22;
            this.salir_btn.Text = "Salir";
            this.salir_btn.UseVisualStyleBackColor = true;
            this.salir_btn.Click += new System.EventHandler(this.salir_btn_Click);
            // 
            // texto_txb
            // 
            this.texto_txb.Location = new System.Drawing.Point(68, 584);
            this.texto_txb.Name = "texto_txb";
            this.texto_txb.Size = new System.Drawing.Size(197, 20);
            this.texto_txb.TabIndex = 22;
            // 
            // abrir_pbx
            // 
            this.abrir_pbx.BackColor = System.Drawing.Color.RoyalBlue;
            this.abrir_pbx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.abrir_pbx.Image = global::Paint_MB.Properties.Resources.folder1;
            this.abrir_pbx.Location = new System.Drawing.Point(64, 12);
            this.abrir_pbx.Name = "abrir_pbx";
            this.abrir_pbx.Size = new System.Drawing.Size(46, 46);
            this.abrir_pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.abrir_pbx.TabIndex = 20;
            this.abrir_pbx.TabStop = false;
            this.abrir_pbx.Click += new System.EventHandler(this.abrir_pbx_Click);
            // 
            // texto_pbx
            // 
            this.texto_pbx.BackColor = System.Drawing.Color.RoyalBlue;
            this.texto_pbx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.texto_pbx.Image = global::Paint_MB.Properties.Resources.texto;
            this.texto_pbx.Location = new System.Drawing.Point(11, 532);
            this.texto_pbx.Name = "texto_pbx";
            this.texto_pbx.Size = new System.Drawing.Size(46, 46);
            this.texto_pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.texto_pbx.TabIndex = 21;
            this.texto_pbx.TabStop = false;
            this.texto_pbx.Click += new System.EventHandler(this.accion);
            // 
            // guardar_pbx
            // 
            this.guardar_pbx.BackColor = System.Drawing.Color.RoyalBlue;
            this.guardar_pbx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guardar_pbx.Image = global::Paint_MB.Properties.Resources.disket;
            this.guardar_pbx.Location = new System.Drawing.Point(12, 12);
            this.guardar_pbx.Name = "guardar_pbx";
            this.guardar_pbx.Size = new System.Drawing.Size(46, 46);
            this.guardar_pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guardar_pbx.TabIndex = 19;
            this.guardar_pbx.TabStop = false;
            this.guardar_pbx.Click += new System.EventHandler(this.guardar_pbx_Click);
            // 
            // linea_pbx
            // 
            this.linea_pbx.BackColor = System.Drawing.Color.RoyalBlue;
            this.linea_pbx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linea_pbx.Image = global::Paint_MB.Properties.Resources.linea1;
            this.linea_pbx.Location = new System.Drawing.Point(12, 116);
            this.linea_pbx.Name = "linea_pbx";
            this.linea_pbx.Size = new System.Drawing.Size(46, 46);
            this.linea_pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.linea_pbx.TabIndex = 14;
            this.linea_pbx.TabStop = false;
            this.linea_pbx.Click += new System.EventHandler(this.accion);
            // 
            // triangulo_pbx
            // 
            this.triangulo_pbx.BackColor = System.Drawing.Color.RoyalBlue;
            this.triangulo_pbx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.triangulo_pbx.Image = global::Paint_MB.Properties.Resources.triangulo;
            this.triangulo_pbx.Location = new System.Drawing.Point(12, 376);
            this.triangulo_pbx.Name = "triangulo_pbx";
            this.triangulo_pbx.Size = new System.Drawing.Size(46, 46);
            this.triangulo_pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.triangulo_pbx.TabIndex = 17;
            this.triangulo_pbx.TabStop = false;
            this.triangulo_pbx.Click += new System.EventHandler(this.accion);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(61, 438);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "No. Caras";
            // 
            // circulo_pbx
            // 
            this.circulo_pbx.BackColor = System.Drawing.Color.RoyalBlue;
            this.circulo_pbx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.circulo_pbx.Image = global::Paint_MB.Properties.Resources.circulo;
            this.circulo_pbx.Location = new System.Drawing.Point(11, 324);
            this.circulo_pbx.Name = "circulo_pbx";
            this.circulo_pbx.Size = new System.Drawing.Size(46, 46);
            this.circulo_pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.circulo_pbx.TabIndex = 16;
            this.circulo_pbx.TabStop = false;
            this.circulo_pbx.Click += new System.EventHandler(this.accion);
            // 
            // rectangulo_pbx
            // 
            this.rectangulo_pbx.BackColor = System.Drawing.Color.RoyalBlue;
            this.rectangulo_pbx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rectangulo_pbx.Image = global::Paint_MB.Properties.Resources.rectangulo;
            this.rectangulo_pbx.Location = new System.Drawing.Point(11, 272);
            this.rectangulo_pbx.Name = "rectangulo_pbx";
            this.rectangulo_pbx.Size = new System.Drawing.Size(46, 46);
            this.rectangulo_pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.rectangulo_pbx.TabIndex = 15;
            this.rectangulo_pbx.TabStop = false;
            this.rectangulo_pbx.Click += new System.EventHandler(this.accion);
            // 
            // caras_txb
            // 
            this.caras_txb.Location = new System.Drawing.Point(64, 454);
            this.caras_txb.Name = "caras_txb";
            this.caras_txb.Size = new System.Drawing.Size(45, 20);
            this.caras_txb.TabIndex = 2;
            // 
            // cuadrado_pbx
            // 
            this.cuadrado_pbx.BackColor = System.Drawing.Color.RoyalBlue;
            this.cuadrado_pbx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cuadrado_pbx.Image = global::Paint_MB.Properties.Resources.cuadrado;
            this.cuadrado_pbx.Location = new System.Drawing.Point(11, 220);
            this.cuadrado_pbx.Name = "cuadrado_pbx";
            this.cuadrado_pbx.Size = new System.Drawing.Size(46, 46);
            this.cuadrado_pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.cuadrado_pbx.TabIndex = 14;
            this.cuadrado_pbx.TabStop = false;
            this.cuadrado_pbx.Click += new System.EventHandler(this.accion);
            // 
            // borrador_pbx
            // 
            this.borrador_pbx.BackColor = System.Drawing.Color.RoyalBlue;
            this.borrador_pbx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.borrador_pbx.Image = global::Paint_MB.Properties.Resources.borrador2;
            this.borrador_pbx.Location = new System.Drawing.Point(11, 168);
            this.borrador_pbx.Name = "borrador_pbx";
            this.borrador_pbx.Size = new System.Drawing.Size(46, 46);
            this.borrador_pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.borrador_pbx.TabIndex = 13;
            this.borrador_pbx.TabStop = false;
            this.borrador_pbx.Click += new System.EventHandler(this.accion);
            // 
            // poligono_pbx
            // 
            this.poligono_pbx.BackColor = System.Drawing.Color.RoyalBlue;
            this.poligono_pbx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.poligono_pbx.Image = global::Paint_MB.Properties.Resources.poligono1;
            this.poligono_pbx.Location = new System.Drawing.Point(12, 428);
            this.poligono_pbx.Name = "poligono_pbx";
            this.poligono_pbx.Size = new System.Drawing.Size(46, 46);
            this.poligono_pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.poligono_pbx.TabIndex = 18;
            this.poligono_pbx.TabStop = false;
            this.poligono_pbx.Click += new System.EventHandler(this.accion);
            // 
            // contador_lbl
            // 
            this.contador_lbl.AutoSize = true;
            this.contador_lbl.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contador_lbl.Location = new System.Drawing.Point(102, 87);
            this.contador_lbl.Name = "contador_lbl";
            this.contador_lbl.Size = new System.Drawing.Size(22, 25);
            this.contador_lbl.TabIndex = 2;
            this.contador_lbl.Text = "1";
            // 
            // mas_pbx
            // 
            this.mas_pbx.BackColor = System.Drawing.Color.RoyalBlue;
            this.mas_pbx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mas_pbx.Image = global::Paint_MB.Properties.Resources.mas;
            this.mas_pbx.Location = new System.Drawing.Point(130, 89);
            this.mas_pbx.Name = "mas_pbx";
            this.mas_pbx.Size = new System.Drawing.Size(32, 23);
            this.mas_pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.mas_pbx.TabIndex = 11;
            this.mas_pbx.TabStop = false;
            this.mas_pbx.Click += new System.EventHandler(this.tamaño);
            // 
            // menos_pbx
            // 
            this.menos_pbx.BackColor = System.Drawing.Color.RoyalBlue;
            this.menos_pbx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menos_pbx.Image = global::Paint_MB.Properties.Resources.menos;
            this.menos_pbx.Location = new System.Drawing.Point(64, 87);
            this.menos_pbx.Name = "menos_pbx";
            this.menos_pbx.Size = new System.Drawing.Size(32, 23);
            this.menos_pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.menos_pbx.TabIndex = 12;
            this.menos_pbx.TabStop = false;
            this.menos_pbx.Click += new System.EventHandler(this.tamaño);
            // 
            // colorActual_pbx
            // 
            this.colorActual_pbx.BackColor = System.Drawing.Color.Transparent;
            this.colorActual_pbx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.colorActual_pbx.Location = new System.Drawing.Point(12, 631);
            this.colorActual_pbx.Name = "colorActual_pbx";
            this.colorActual_pbx.Size = new System.Drawing.Size(20, 46);
            this.colorActual_pbx.TabIndex = 10;
            this.colorActual_pbx.TabStop = false;
            // 
            // manoAlzada_pbx
            // 
            this.manoAlzada_pbx.BackColor = System.Drawing.Color.RoyalBlue;
            this.manoAlzada_pbx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.manoAlzada_pbx.Image = global::Paint_MB.Properties.Resources.Lapiz;
            this.manoAlzada_pbx.Location = new System.Drawing.Point(12, 64);
            this.manoAlzada_pbx.Name = "manoAlzada_pbx";
            this.manoAlzada_pbx.Size = new System.Drawing.Size(46, 46);
            this.manoAlzada_pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.manoAlzada_pbx.TabIndex = 0;
            this.manoAlzada_pbx.TabStop = false;
            this.manoAlzada_pbx.Click += new System.EventHandler(this.accion);
            // 
            // paleta_pbx
            // 
            this.paleta_pbx.BackColor = System.Drawing.Color.Transparent;
            this.paleta_pbx.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("paleta_pbx.BackgroundImage")));
            this.paleta_pbx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.paleta_pbx.Image = global::Paint_MB.Properties.Resources.arco;
            this.paleta_pbx.Location = new System.Drawing.Point(141, 657);
            this.paleta_pbx.Name = "paleta_pbx";
            this.paleta_pbx.Size = new System.Drawing.Size(20, 20);
            this.paleta_pbx.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.paleta_pbx.TabIndex = 9;
            this.paleta_pbx.TabStop = false;
            this.paleta_pbx.Click += new System.EventHandler(this.eleccionColor);
            // 
            // cafe_pbx
            // 
            this.cafe_pbx.BackColor = System.Drawing.Color.Brown;
            this.cafe_pbx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cafe_pbx.Location = new System.Drawing.Point(89, 631);
            this.cafe_pbx.Name = "cafe_pbx";
            this.cafe_pbx.Size = new System.Drawing.Size(20, 20);
            this.cafe_pbx.TabIndex = 8;
            this.cafe_pbx.TabStop = false;
            this.cafe_pbx.Click += new System.EventHandler(this.eleccionColor);
            // 
            // rosa_pbx
            // 
            this.rosa_pbx.BackColor = System.Drawing.Color.Pink;
            this.rosa_pbx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rosa_pbx.Location = new System.Drawing.Point(115, 657);
            this.rosa_pbx.Name = "rosa_pbx";
            this.rosa_pbx.Size = new System.Drawing.Size(20, 20);
            this.rosa_pbx.TabIndex = 7;
            this.rosa_pbx.TabStop = false;
            this.rosa_pbx.Click += new System.EventHandler(this.eleccionColor);
            // 
            // negro_pbx
            // 
            this.negro_pbx.BackColor = System.Drawing.Color.Black;
            this.negro_pbx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.negro_pbx.Location = new System.Drawing.Point(37, 631);
            this.negro_pbx.Name = "negro_pbx";
            this.negro_pbx.Size = new System.Drawing.Size(20, 20);
            this.negro_pbx.TabIndex = 1;
            this.negro_pbx.TabStop = false;
            this.negro_pbx.Click += new System.EventHandler(this.eleccionColor);
            // 
            // gris_pbx
            // 
            this.gris_pbx.BackColor = System.Drawing.Color.Gray;
            this.gris_pbx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gris_pbx.Location = new System.Drawing.Point(63, 631);
            this.gris_pbx.Name = "gris_pbx";
            this.gris_pbx.Size = new System.Drawing.Size(20, 20);
            this.gris_pbx.TabIndex = 6;
            this.gris_pbx.TabStop = false;
            this.gris_pbx.Click += new System.EventHandler(this.eleccionColor);
            // 
            // blanco_pbx
            // 
            this.blanco_pbx.BackColor = System.Drawing.Color.White;
            this.blanco_pbx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.blanco_pbx.Location = new System.Drawing.Point(37, 657);
            this.blanco_pbx.Name = "blanco_pbx";
            this.blanco_pbx.Size = new System.Drawing.Size(20, 20);
            this.blanco_pbx.TabIndex = 2;
            this.blanco_pbx.TabStop = false;
            this.blanco_pbx.Click += new System.EventHandler(this.eleccionColor);
            // 
            // azul_pbx
            // 
            this.azul_pbx.BackColor = System.Drawing.Color.Blue;
            this.azul_pbx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.azul_pbx.Location = new System.Drawing.Point(89, 657);
            this.azul_pbx.Name = "azul_pbx";
            this.azul_pbx.Size = new System.Drawing.Size(20, 20);
            this.azul_pbx.TabIndex = 5;
            this.azul_pbx.TabStop = false;
            this.azul_pbx.Click += new System.EventHandler(this.eleccionColor);
            // 
            // rojo_pbx
            // 
            this.rojo_pbx.BackColor = System.Drawing.Color.Red;
            this.rojo_pbx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rojo_pbx.Location = new System.Drawing.Point(115, 631);
            this.rojo_pbx.Name = "rojo_pbx";
            this.rojo_pbx.Size = new System.Drawing.Size(20, 20);
            this.rojo_pbx.TabIndex = 0;
            this.rojo_pbx.TabStop = false;
            this.rojo_pbx.Click += new System.EventHandler(this.eleccionColor);
            // 
            // verde_pbx
            // 
            this.verde_pbx.BackColor = System.Drawing.Color.Green;
            this.verde_pbx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.verde_pbx.Location = new System.Drawing.Point(63, 657);
            this.verde_pbx.Name = "verde_pbx";
            this.verde_pbx.Size = new System.Drawing.Size(20, 20);
            this.verde_pbx.TabIndex = 4;
            this.verde_pbx.TabStop = false;
            this.verde_pbx.Click += new System.EventHandler(this.eleccionColor);
            // 
            // amarillo_pbx
            // 
            this.amarillo_pbx.BackColor = System.Drawing.Color.Yellow;
            this.amarillo_pbx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.amarillo_pbx.Location = new System.Drawing.Point(141, 631);
            this.amarillo_pbx.Name = "amarillo_pbx";
            this.amarillo_pbx.Size = new System.Drawing.Size(20, 20);
            this.amarillo_pbx.TabIndex = 3;
            this.amarillo_pbx.TabStop = false;
            this.amarillo_pbx.Click += new System.EventHandler(this.eleccionColor);
            // 
            // Paint
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1350, 729);
            this.Controls.Add(this.menu_pnl);
            this.Controls.Add(this.panel);
            this.Name = "Paint";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.LocationChanged += new System.EventHandler(this.CambiarForm);
            this.SizeChanged += new System.EventHandler(this.CambiarForm);
            this.menu_pnl.ResumeLayout(false);
            this.menu_pnl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.paste_pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.recortar_pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.adelante_pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.atras_pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.relleno_pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.abrir_pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.texto_pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guardar_pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.linea_pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.triangulo_pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.circulo_pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rectangulo_pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cuadrado_pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.borrador_pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.poligono_pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mas_pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.menos_pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.colorActual_pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.manoAlzada_pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.paleta_pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cafe_pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rosa_pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.negro_pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gris_pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco_pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.azul_pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rojo_pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.verde_pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.amarillo_pbx)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.Panel menu_pnl;
        private System.Windows.Forms.PictureBox manoAlzada_pbx;
        private System.Windows.Forms.PictureBox rojo_pbx;
        private System.Windows.Forms.PictureBox paleta_pbx;
        private System.Windows.Forms.PictureBox cafe_pbx;
        private System.Windows.Forms.PictureBox rosa_pbx;
        private System.Windows.Forms.PictureBox negro_pbx;
        private System.Windows.Forms.PictureBox gris_pbx;
        private System.Windows.Forms.PictureBox blanco_pbx;
        private System.Windows.Forms.PictureBox azul_pbx;
        private System.Windows.Forms.PictureBox verde_pbx;
        private System.Windows.Forms.PictureBox amarillo_pbx;
        private System.Windows.Forms.PictureBox colorActual_pbx;
        private System.Windows.Forms.PictureBox mas_pbx;
        private System.Windows.Forms.PictureBox menos_pbx;
        private System.Windows.Forms.Label contador_lbl;
        private System.Windows.Forms.PictureBox borrador_pbx;
        private System.Windows.Forms.PictureBox cuadrado_pbx;
        private System.Windows.Forms.PictureBox rectangulo_pbx;
        private System.Windows.Forms.PictureBox linea_pbx;
        private System.Windows.Forms.PictureBox circulo_pbx;
        private System.Windows.Forms.PictureBox triangulo_pbx;
        private System.Windows.Forms.PictureBox poligono_pbx;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox caras_txb;
        private System.Windows.Forms.PictureBox guardar_pbx;
        private System.Windows.Forms.PictureBox abrir_pbx;
        private System.Windows.Forms.Button limpiar_btn;
        private System.Windows.Forms.PictureBox texto_pbx;
        private System.Windows.Forms.TextBox texto_txb;
        private System.Windows.Forms.TextBox letraTamaño_txb;
        private System.Windows.Forms.Button salir_btn;
        private System.Windows.Forms.PictureBox relleno_pbx;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox atras_pbx;
        private System.Windows.Forms.PictureBox adelante_pbx;
        private System.Windows.Forms.PictureBox recortar_pbx;
        private System.Windows.Forms.PictureBox paste_pbx;
    }
}

