﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Paint_MB
{
    public partial class Paint : Form
    {
        Graphics g;
        Graphics copy;
        Graphics rectCut;


        Point sp = new Point(0, 0);
        Point ep = new Point(0, 0);
        private int pX, pY, x, y, dX, dY;
        //Color General
        Color color;
        //Si se presiona o no el mouse
        int indice = 0;
        //Seleccion de figura
        int figura = 0;
        //Grosor Inicial
        int grosor = 1;
        //Caras para poligono
        int contadorCaras = 0;
        //Puntos Triangulo
        Point v1;
        Point v2;
        Point v3;

        Bitmap[] lista = new Bitmap[2500];
        Bitmap bmp;
        Bitmap cut;


        int contPantalla = 0;

        //floopfill
        Bitmap bm;
        Graphics gp;
        Point cp;

        public Paint()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            g = panel.CreateGraphics();

            WindowState = FormWindowState.Maximized;
            //if (WindowState == FormWindowState.Minimized)
            //{
            //    panel.Refresh();
            //}
        }
        void tamaño(object sender, EventArgs e)
        {
            PictureBox tamaño = (PictureBox)sender;

            if (tamaño == mas_pbx)
            {
                grosor += 1;

            }
            else
            {
                if (grosor > 1)
                {
                    grosor -= 1;
                }
            }
            this.contador_lbl.Text = grosor.ToString();
        }
        void eleccionColor(object sender, EventArgs e)
        {
            PictureBox eleccion = (PictureBox)sender;
            switch (eleccion.Name)
            {
                case "negro_pbx":
                    color = Color.Black;

                    break;
                case "gris_pbx":
                    color = Color.Gray;

                    break;
                case "cafe_pbx":
                    color = Color.Brown;

                    break;
                case "rojo_pbx":
                    color = Color.Red;

                    break;
                case "amarillo_pbx":
                    color = Color.Yellow;

                    break;
                case "blanco_pbx":
                    color = Color.White;

                    break;
                case "verde_pbx":
                    color = Color.Green;

                    break;
                case "azul_pbx":
                    color = Color.Blue;

                    break;
                case "rosa_pbx":
                    color = Color.Pink;

                    break;
                case "paleta_pbx":
                    ColorDialog diag = new ColorDialog();
                    diag.ShowDialog();
                    color = diag.Color;
                    break;
            }
            colorActual_pbx.BackColor = color;
        }

        private void guardar_pbx_Click(object sender, EventArgs e)
        {
            save();
        }



        private void limpiar_btn_Click(object sender, EventArgs e)
        {
            panel.Refresh();
            panel.BackgroundImage = null;      
        }

        private void salir_btn_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Guardar dibujo?", "Mendoza Barron", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                save();
            }
            else
            {
                this.Dispose();
            }
        }

        void accion(object sender, EventArgs e)
        {
            PictureBox accion = (PictureBox)sender;

            switch (accion.Name)
            {
                case "linea_pbx":
                    figura = 0;
                    break;
                case "manoAlzada_pbx":
                    figura = 1;
                    break;
                case "borrador_pbx":
                    figura = 2;
                    break;
                case "cuadrado_pbx":
                    figura = 3;
                    break;
                case "rectangulo_pbx":
                    figura = 4;
                    break;
                case "circulo_pbx":
                    figura = 5;
                    break;
                case "triangulo_pbx":
                    figura = 6;
                    break;
                case "poligono_pbx":
                    figura = 7;
                    break;
                case "texto_pbx":
                    figura = 8;
                    break;
                case "relleno_pbx":
                    figura = 9;
                    break;
                case "recortar_pbx":
                    figura = 10;
                    break;
                case "paste_pbx":
                    figura = 11;
                    break;
            }

        }

 

        private void CambiarForm(object sender, EventArgs e)
        {
           // MessageBox.Show("JALADOS");
            panel.BackgroundImage = lista[contPantalla];
            panel.Refresh();
        }


        void panel_MouseMove(object sender, MouseEventArgs e)
        {
            if (indice == 1)
            {
                ep = e.Location;
                x = e.X;
                y = e.Y;

                switch (figura)
                {
                    case 1:
                        g.DrawLine(new Pen(color,grosor), sp, ep);

                        break;
                    case 2:
                        g.FillEllipse(new SolidBrush(Color.White), e.X, e.Y, 100, 100);

                        break;
                }
                sp = ep;
            }
        }
        private void panel_MouseClick(object sender, MouseEventArgs e)
        {

            if (indice == 1)
            {
                x = e.X;
                y = e.Y;
                dX = e.X - pX;
                dY = e.Y - pY;
                switch (figura)
                {
                    case 0://LINEA
                        g.DrawLine(new Pen(color), pX, pY, e.X, e.Y);
                        break;
                    case 3://CUADRADO
                        g.DrawRectangle(new Pen(color), pX, pY, dX, dX);
                        break;
                    case 4://RECTANGULO
                        g.DrawRectangle(new Pen(color), pX, pY, dX, dY);
                        break;
                    case 5://CIRCULO
                        g.DrawEllipse(new Pen(color), pX, pY, dX, dX);
                        break;
                    case 8://TEXTO
                        try
                        {
                            String texto = texto_txb.Text;
                            int letraTamaño = Convert.ToInt32(letraTamaño_txb.Text);
                            SolidBrush drawBrush = new SolidBrush(color);
                            g.DrawString(texto, new Font(FontFamily.GenericSansSerif, letraTamaño), drawBrush, new Point(x, y));
                        }
                        catch
                        {
                            MessageBox.Show("Operación inválida");
                        }

                        break;
                    case 9://pintar

                        try
                        {
                            cp = this.PointToClient(Cursor.Position);
                            tobien1(bmp, cp, color, Color.Blue);
                            g.DrawImage(bmp, new Point(0, 0));
                        }
                        catch
                        {
                            panel.BackColor = color;
                        }
                        break;
                    case 10://recortar
                        g.DrawRectangle(new Pen(panel.BackColor), pX, pY, dX, dY);
                        cut=Copiar(pX, pY, dX, dY);

                        break;
                    case 11://pegar
                        cp = this.PointToClient(Cursor.Position);

                        g.DrawImage(cut,cp);
                        break;
                }
            }
        }
        void panel_MouseDown(object sender, MouseEventArgs e)
        {
            sp = e.Location;
            pX = e.X;
            pY = e.Y;

            indice = 1;
            if (figura == 6)
            {
                contadorCaras++;

                switch (contadorCaras)
                {
                    case 1:
                        v1 = new Point(e.X, e.Y);
                        break;
                    case 2:
                        v2 = new Point(e.X, e.Y);
                        g.DrawLine(new Pen(color), v1, v2);
                        break;
                    case 3:
                        v3 = new Point(e.X, e.Y);
                        g.DrawLine(new Pen(color), v3, v2);
                        g.DrawLine(new Pen(color), v3, v1);
                        break;
                }
                if (contadorCaras == 3)
                {
                    contadorCaras = 0;
                }

            }

            if (figura==7)
            {
                contadorCaras++;
                try
                {
                    int num = Convert.ToInt32(caras_txb.Text);

                        if (contadorCaras == 1)
                        {
                            v1 = new Point(e.X, e.Y);
                            v2 = new Point(e.X, e.Y);
                        }
                        if (contadorCaras < num + 1)
                        {
                            g.DrawLine(new Pen(color), v2, new Point(e.X, e.Y));
                            v2 = new Point(e.X, e.Y);
                        }
                        if (contadorCaras == num + 1)
                        {
                            g.DrawLine(new Pen(color), v2, v1);
                            contadorCaras = 0;
                        }  
                }
                catch
                {
                    MessageBox.Show("Operacion Invalida");
                }
            }
        }
        private void panel_MouseUp(object sender, MouseEventArgs e)
        {
            indice = 0;
            GuardarPantalla();

        }
        private void abrir_pbx_Click(object sender, EventArgs e)
        {
            OpenFileDialog o = new OpenFileDialog();
            o.Filter = "Png files|*.png|jpeg files|*jpg|bitmaps|*.bmp";
            if (o.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                panel.BackgroundImage = (Image)Image.FromFile(o.FileName).Clone();
            }
        }
        void save()
        {
            Bitmap bmp = new Bitmap(panel.Width, panel.Height);
            Graphics g = Graphics.FromImage(bmp);
            Rectangle rect = panel.RectangleToScreen(panel.ClientRectangle);
            g.CopyFromScreen(rect.Location, Point.Empty, panel.Size);
            g.Dispose();
            SaveFileDialog s = new SaveFileDialog();
            s.Filter = "Png files|*.png|jpeg files|*jpg|bitmaps|*.bmp";
            if (s.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                if (File.Exists(s.FileName))
                {
                    File.Delete(s.FileName);
                }
                if (s.FileName.Contains(".jpg"))
                {
                    bmp.Save(s.FileName, ImageFormat.Jpeg);
                }
                else if (s.FileName.Contains(".png"))
                {
                    bmp.Save(s.FileName, ImageFormat.Png);
                }
                else if (s.FileName.Contains(".bmp"))
                {
                    bmp.Save(s.FileName, ImageFormat.Bmp);
                }
            }
        }

        void GuardarPantalla()
        {
            contPantalla++;
            lista[contPantalla] = CapturaPantalla();
        }

        Bitmap CapturaPantalla()
        {
            bmp = new Bitmap(panel.Width, panel.Height);
            copy = Graphics.FromImage(bmp);
            Rectangle rect = panel.RectangleToScreen(panel.ClientRectangle);

            copy.CopyFromScreen(rect.Location, Point.Empty, panel.Size);
            copy.Dispose();
            return bmp;
        }

        Bitmap Copiar(int x,int y, int w, int h)
        {
            cut = new Bitmap(w, h);
            rectCut = Graphics.FromImage(cut);
            Rectangle rect = panel.RectangleToScreen(panel.ClientRectangle);

            rectCut.CopyFromScreen(new Point(x,y+23), Point.Empty, rect.Size);
           

            rectCut.Dispose();
            return cut;
        }

        private void atras_pbx_Click(object sender, EventArgs e)
        {
            if (contPantalla == 0)
            {
                MessageBox.Show("No hay");
            }
            else if (contPantalla > 0)
            {
                contPantalla--;
                panel.BackgroundImage = lista[contPantalla];
                panel.Refresh();
            }
        }

        private void adelante_pbx_Click(object sender, EventArgs e)
        {
            if (lista[contPantalla + 1] != null)
            {
                contPantalla++;
                panel.BackgroundImage = lista[contPantalla];
                panel.Refresh();
            }
            else
            {
                MessageBox.Show("No hay");
            }
        }


        private bool SameColor(Color c1, Color c2)
        {
            return ((c1.A == c2.A) && (c1.B == c2.B) && (c1.G == c2.G) && (c1.R == c2.R));
        }
        private void tobien1(Bitmap bm, Point p, Color Color, Color LineColor)
        {
            Stack<Point> S = new Stack<Point>();

            S.Push(p);
            while (S.Count != 0)
            {

                p = S.Pop();
                Color CurrentColor = bm.GetPixel(p.X, p.Y);
                if (!SameColor(CurrentColor, Color) && SameColor(CurrentColor, panel.BackColor))
                {
                    bm.SetPixel(p.X, p.Y, Color);
                    S.Push(new Point(p.X - 1, p.Y));
                    S.Push(new Point(p.X + 1, p.Y));
                    S.Push(new Point(p.X, p.Y - 1));
                    S.Push(new Point(p.X, p.Y + 1));
                }
            }
        }

    }

}
